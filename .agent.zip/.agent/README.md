# 🛠️ CLI Builder Team

> **Build any CLI tool from unstructured prompts** — with zero assumptions, proper communication, and production-quality output.

---

## How It Works

```
User's vague prompt
        │
        ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│   🔍 Analyst  │ ──► │  🏗️ Architect │ ──► │  🛠️ Builder   │
│  Parse & Spec │     │ Design System │     │  Implement    │
└───────────────┘     └───────────────┘     └───────────────┘
                                                    │
                                                    ▼
                                            ┌───────────────┐     ┌───────────────┐
                                            │  🔒 Guardian  │ ──► │  🚀 Operator  │
                                            │  Test & Audit │     │  Ship & Dist  │
                                            └───────────────┘     └───────────────┘
```

---

## Team Roles

| # | Role | Persona File | Responsibility |
|---|------|--------------|----------------|
| 1 | **The Analyst** | `persona/analyst.md` | Parse vague prompts → structured spec |
| 2 | **The Architect** | `persona/architect.md` | Choose stack, design modules |
| 3 | **The Builder** | `persona/builder.md` | Implement CLI, write code |
| 4 | **The Guardian** | `persona/guardian.md` | Test, debug, security audit |
| 5 | **The Operator** | `persona/operator.md` | Package, distribute, CI/CD |

---

## Skills Inventory (18 skills)

### Architecture & Planning
| Skill | Purpose |
|-------|---------|
| `architecture` | System design, component structure |
| `senior-architect` | Scalability, ADRs, trade-offs |
| `plan-writing` | Technical specs and documentation |

### Development
| Skill | Purpose |
|-------|---------|
| `python-patterns` | Python CLIs (Typer, Click, async) |
| `typescript-expert` | TypeScript CLIs (Commander, oclif) |
| `nodejs-best-practices` | Node.js ecosystem patterns |
| `bash-linux` | Shell scripting, command conventions |
| `clean-code` | Code quality, readability |
| `api-patterns` | REST/GraphQL API design |
| `mcp-builder` | MCP server/tool development |
| `agent-tool-builder` | Tool schema design |

### Quality & Security
| Skill | Purpose |
|-------|---------|
| `systematic-debugging` | Root-cause analysis workflow |
| `test-driven-development` | TDD patterns and test suites |
| `api-security-best-practices` | Credential handling, input validation |

### DevOps & AI
| Skill | Purpose |
|-------|---------|
| `deployment-procedures` | Release management, versioning |
| `docker-expert` | Containerization, multi-stage builds |
| `prompt-engineering` | Prompt design for AI-powered CLIs |
| `skill-creator` | Create new skills on demand |

---

## Workflows

| Workflow | Purpose |
|----------|---------|
| `workflows/orchestration.md` | Full dev lifecycle: Plan → Build → Test → Ship |
| `workflows/requirement-intake.md` | Parse unstructured prompts into specs |
| `workflows/communication-protocol.md` | Zero-assumption communication rules |

---

## Quick Start

1. **Read the prompt** from the user
2. **Run** `workflows/requirement-intake.md` to produce a structured spec
3. **Follow** `workflows/orchestration.md` phase by phase
4. **Use** `workflows/communication-protocol.md` whenever unclear on anything

---

## Technology Stack Recommendations

| Signal in Requirements | Recommended Stack |
|------------------------|-------------------|
| Scripting, AI integration, rapid dev | **Python** + Typer |
| Type safety, npm ecosystem | **TypeScript** + Commander/oclif |
| Single binary, high performance | **Go** + Cobra |
| Systems-level, max performance | **Rust** + clap |

---

*Built from curated analysis of 700+ skills across 8 repositories.*
