---
description: Zero-assumption communication rules for the CLI Builder Team — when to ask, how to report, and how to escalate.
---

# 🗣️ Communication Protocol

> **Core Rule**: Never assume. Always clarify. Ship with confidence, not hope.

---

## The Golden Rules

1. **No Silent Assumptions** — If you're unsure, ask. A 30-second question saves hours of rework.
2. **Decisions Need Receipts** — Every significant decision must be documented with rationale.
3. **Blockers Surface Immediately** — Don't wait for a standup. Flag blockers the moment they appear.
4. **One Source of Truth** — The requirements spec and architecture spec are canonical. If they're wrong, update them first.

---

## When to ASK vs. When to DECIDE

### Always ASK the User

- Language / framework choice (unless spec says "you decide")
- Adding new dependencies not in the spec
- Changing the command structure or public interface
- Removing a feature from scope
- Security trade-offs (e.g., storing secrets in plaintext vs. keyring)

### OK to DECIDE Independently

- Internal code organization and file naming
- Which test framework to use (unless user has a preference)
- Implementation details that don't affect the public interface
- Formatting, linting, and code style tools
- Commit message wording

---

## Communication Templates

### Status Update

```markdown
## Status Update — [Date]

**Role**: [Analyst / Architect / Builder / Guardian / Operator]
**Phase**: [Intake / Design / Build / Test / Ship]

### Completed
- <what was finished>

### In Progress
- <what's being worked on>

### Blockers
- <anything blocking progress — or "None">

### Decisions Made
- <decision>: <rationale>

### Questions for User
1. <question>
```

### Bug Report (Guardian → Builder)

```markdown
## Bug Report

**Severity**: [Critical / High / Medium / Low]
**Command**: `<tool> <command> <args>`
**Expected**: <what should happen>
**Actual**: <what actually happens>
**Steps to Reproduce**:
1. <step>
2. <step>

**Environment**: <OS, language version, etc.>
```

### Handoff

```markdown
## Handoff: [From Role] → [To Role]

**Artifact**: <file or folder being handed off>
**Status**: <what's done, what's expected next>
**Open Items**: <anything the next role should know>
```

---

## Escalation Path

```
Level 1: Ask within the team (role-to-role)
    │
    ▼ (if unresolved)
Level 2: Ask the user for clarification
    │
    ▼ (if user is unavailable)
Level 3: Document assumption clearly and mark as "ASSUMED — needs confirmation"
```

> [!CAUTION]
> Level 3 (making an assumption) is a **last resort**. Every assumption must be tagged `<!-- ASSUMED -->` in the spec so it can be reviewed later.

---

## Commit Message Convention

```
<type>(<scope>): <short description>

Types: feat, fix, docs, test, chore, refactor
Scope: command name, module name, or "cli"

Examples:
  feat(voice): add push-to-talk hotkey support
  fix(config): handle missing API key gracefully
  test(transcribe): add unit tests for whisper adapter
  docs(readme): update install instructions
```

---

## Review Checkpoints

| Checkpoint | Who Reviews | What's Reviewed |
|------------|-------------|-----------------|
| Requirements sign-off | User + Analyst | `requirements-spec.md` |
| Architecture approval | User + Architect | `architecture-spec.md` |
| Milestone demo | User + Builder | Working CLI subset |
| Security sign-off | Guardian | Full security checklist |
| Release approval | Guardian + Operator | Final package + tests |
