---
description: Step-by-step process for converting unstructured user prompts into a structured CLI requirements spec.
---

# 📋 Requirement Intake Workflow

> Turn any vague, messy user prompt into a crisp, buildable requirements spec.

---

## Step 1: Receive the Raw Prompt

Capture the user's exact words. Do **NOT** interpret, rephrase, or fill gaps yet.

```
📥 Raw Input: "<paste user's exact prompt here>"
```

---

## Step 2: Run the Clarification Checklist

Go through each item below. If the user's prompt doesn't answer it, **ASK** — never assume.

### Must-Have Clarifications

| # | Question | Example Answers |
|---|----------|-----------------|
| 1 | **Tool name** — What should the CLI be called? | `voice-keyboard-cli`, `data-sync` |
| 2 | **Purpose** — What problem does it solve in one sentence? | "Converts voice input to keyboard events" |
| 3 | **Target users** — Who will use this? | Developers, end-users, DevOps |
| 4 | **Platform** — Which OS(es)? | Windows only, cross-platform, Linux servers |
| 5 | **Language preference** — Any constraint? | Python, Node, Go, or "you decide" |
| 6 | **Input sources** — Where does data come from? | CLI args, stdin, files, API, microphone |
| 7 | **Output format** — What does the tool produce? | Stdout text, JSON, files, system actions |
| 8 | **Dependencies** — Any required external services? | APIs, databases, hardware |
| 9 | **Config** — Does it need configuration? | Env vars, config file, flags only |
| 10 | **Scope** — MVP or full-featured? | "Just the basics" vs. "production-ready" |

### Nice-to-Have Clarifications

| # | Question | Why It Matters |
|---|----------|----------------|
| 11 | Install method preference? | pip, npm, brew, binary |
| 12 | Existing codebase to integrate with? | Affects architecture decisions |
| 13 | Performance requirements? | Affects language/stack choice |
| 14 | AI/LLM integration needed? | Adds agent skills to the mix |
| 15 | Interactive or non-interactive? | Affects I/O design |

---

## Step 3: Produce the Requirements Spec

Fill in the template below with confirmed answers:

```markdown
# Requirements Spec: <tool-name>

## Overview
<One paragraph describing what the tool does and why>

## Functional Requirements
1. <Requirement 1>
2. <Requirement 2>
3. ...

## Non-Functional Requirements
- Platform: <OS list>
- Language: <chosen language>
- Performance: <any constraints>

## Input / Output Contract
- **Input**: <sources and formats>
- **Output**: <formats and destinations>

## Command Structure
- `<tool> <command> [options]`
- `<tool> <command2> [options]`

## Config Management
- <How the tool is configured>

## Error Handling
- <Expected error scenarios and how to handle them>

## Open Questions
- <Any unresolved items>
```

---

## Step 4: Validate with User

Present the spec back to the user and ask:

> "Here's what I understand you want. Is this correct? Anything to add or change?"

**DO NOT proceed to architecture until the user confirms.**

---

## Step 5: Hand Off

Once confirmed, hand the `requirements-spec.md` to **The Architect** (see `persona/architect.md`).

---

## Example: Before & After

### Before (raw user prompt)
> "I want a CLI that listens to my voice and types what I say"

### After (clarification + spec)

| Question | Answer |
|----------|--------|
| Name | `voice-keyboard-cli` |
| Purpose | Captures microphone audio, transcribes via speech-to-text, and simulates keyboard input |
| Platform | Windows (primary), macOS (stretch) |
| Language | Python |
| Input | Microphone audio stream |
| Output | Simulated keystrokes to active window |
| Dependencies | Speech-to-text API (Whisper or Google), keyboard simulation lib |
| Config | Config file for API keys, hotkey to start/stop |
| Scope | MVP — single language, push-to-talk |
