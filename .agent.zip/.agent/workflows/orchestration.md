---
description: Full development lifecycle for building a CLI tool — maps each phase to the right skills and roles.
---

# 🎯 Orchestration Workflow

> Step-by-step lifecycle for taking a CLI tool from idea to production release.

---

## Quick Reference: Skill Lookup

| Phase | When You Need To... | Invoke Skill | Role |
|-------|---------------------|--------------|------|
| **Intake** | Parse vague requirements | `@plan-writing` | Analyst |
| **Design** | Design system architecture | `@senior-architect` | Architect |
| **Design** | Plan data flow | `@architecture` | Architect |
| **Setup** | Structure Python project | `@python-patterns` | Builder |
| **Setup** | Structure TS/Node project | `@typescript-expert` | Builder |
| **Build** | Write shell scripts | `@bash-linux` | Builder |
| **Build** | Design API layer | `@api-patterns` | Builder |
| **Build** | Build MCP tools | `@mcp-builder` | Builder |
| **Build** | Design tool schemas | `@agent-tool-builder` | Builder |
| **Test** | Debug issues | `@systematic-debugging` | Guardian |
| **Test** | Write tests (TDD) | `@test-driven-development` | Guardian |
| **Harden** | Security review | `@api-security-best-practices` | Guardian |
| **Ship** | Containerize | `@docker-expert` | Operator |
| **Ship** | Release management | `@deployment-procedures` | Operator |

---

## Phase 1: Intake & Requirements (Analyst)

**Workflow**: `requirement-intake.md`

```
Steps:
1. Receive user's raw prompt
2. Run clarification checklist (language, platform, I/O, etc.)
3. Produce requirements-spec.md
4. Get user sign-off
5. Hand off to Architect
```

---

## Phase 2: Architecture & Design (Architect)

```
Steps:
1. Review requirements-spec.md
2. Choose technology stack (see README stack matrix)
3. Design module breakdown and command tree
4. Write ADRs for non-obvious decisions
5. Produce architecture-spec.md
6. Get user approval
7. Hand off to Builder
```

**Skills**: `@senior-architect`, `@architecture`, `@api-patterns`

---

## Phase 3: Implementation (Builder)

```
Steps:
1. Initialize project from architecture-spec.md
2. Set up linting, formatting, CI skeleton
3. Implement commands one-by-one:
   a. Write command handler
   b. Add argument/flag parsing
   c. Implement core logic
   d. Add error handling
   e. Write --help text
4. Commit after each command is working
5. Hand off to Guardian at each milestone
```

**Skills**: `@python-patterns`, `@typescript-expert`, `@bash-linux`, `@clean-code`

---

## Phase 4: Testing & Security (Guardian)

```
Steps:
1. Write unit tests for core logic
2. Write integration tests for command pipelines
3. Write E2E tests (run CLI as subprocess)
4. Run security checklist:
   - Credential handling
   - Input validation
   - Path sanitization
   - Exit code compliance
5. File bugs with reproduction steps
6. Sign off when all tests pass
```

**Skills**: `@test-driven-development`, `@systematic-debugging`, `@api-security-best-practices`

---

## Phase 5: Packaging & Release (Operator)

```
Steps:
1. Set up semantic versioning
2. Write CHANGELOG.md
3. Create distribution config:
   - setup.py / pyproject.toml (Python)
   - package.json (Node)
   - Dockerfile (containers)
4. Set up CI/CD pipeline (GitHub Actions)
5. Publish to package registry
6. Verify install works: pip install / npm install / brew install
7. Announce release
```

**Skills**: `@deployment-procedures`, `@docker-expert`

---

## Common Scenarios

### "User gives a one-line prompt"
1. Analyst runs full intake → clarifies everything
2. Normal lifecycle follows

### "Bug found in production"
1. Guardian runs `@systematic-debugging`
2. Builder fixes
3. Guardian re-tests
4. Operator releases patch

### "User wants a new command added"
1. Analyst scopes the new command
2. Architect updates command tree
3. Builder implements
4. Guardian tests
5. Operator bumps minor version

### "Language/stack not decided"
1. Architect presents stack matrix with pros/cons
2. User picks
3. Builder proceeds
